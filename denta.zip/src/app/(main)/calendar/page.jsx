import React from 'react';
import CalendarPage from '@/components/calendar';

export default async function Calendar() {
  return <CalendarPage />;
}
