import React from 'react';
import DashboardPage from '@/components/dashboard';

export default async function Dashboard() {
  return <DashboardPage />;
}
