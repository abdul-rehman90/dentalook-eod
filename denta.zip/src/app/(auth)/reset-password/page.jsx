import React from 'react';
import ResetPasswordForm from '@/components/reset-password';

export default function ResetPasswordPage() {
  return <ResetPasswordForm />;
}
