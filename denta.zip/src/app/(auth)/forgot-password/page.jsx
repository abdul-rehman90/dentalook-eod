import React from 'react';
import ForgotPasswordForm from '@/components/forgot-password';

export default function ForgotPasswordPage() {
  return <ForgotPasswordForm />;
}
