import React, { useEffect, useState } from 'react';
import { GenericTable } from '@/common/components/table/table';
import { useGlobalContext } from '@/common/context/global-context';
import StepNavigation from '@/common/components/step-navigation/step-navigation';

const categoryOptions = [
  { value: 'Growth', label: 'Growth' },
  { value: 'Replacement', label: 'Replacement' }
];

const positionOptions = [
  { value: 'DDS', label: 'DDS' },
  { value: 'RDH', label: 'RDH' },
  { value: 'PCC', label: 'PCC' },
  { value: 'CDA', label: 'CDA' },
  { value: 'PM', label: 'PM' },
  { value: 'Dental Aide', label: 'Dental Aide' }
];

export default function HiringTraining({ onNext }) {
  const [hiringData, setHiringData] = useState([]);
  const [trainingData, setTrainingData] = useState([]);
  const { getCurrentStepData } = useGlobalContext();
  const currentStepData = getCurrentStepData();

  const hiringColumns = [
    {
      width: 100,
      title: 'Title',
      editable: true,
      disabled: true,
      key: 'position',
      inputType: 'select',
      dataIndex: 'position',
      selectOptions: positionOptions
    },
    {
      width: 100,
      editable: true,
      disabled: true,
      key: 'category',
      title: 'Category',
      inputType: 'select',
      dataIndex: 'category',
      selectOptions: categoryOptions
    },
    {
      width: 300,
      key: 'reason',
      disabled: true,
      editable: true,
      title: 'Reason',
      inputType: 'text',
      dataIndex: 'reason'
    }
  ];

  const trainingColumns = [
    {
      width: 100,
      title: 'Title',
      disabled: true,
      editable: true,
      key: 'position',
      inputType: 'select',
      dataIndex: 'position',
      selectOptions: positionOptions
    },
    {
      width: 100,
      key: 'name',
      title: 'Name',
      disabled: true,
      editable: true,
      inputType: 'text',
      dataIndex: 'name'
    },
    {
      width: 300,
      key: 'reason',
      disabled: true,
      editable: true,
      title: 'Reason',
      inputType: 'text',
      dataIndex: 'reason'
    }
  ];

  useEffect(() => {
    if (currentStepData?.hiring.length > 0) {
      const transformedData = currentStepData.hiring.map((item) => ({
        category: item.category,
        key: item.id.toString(),
        reason: item.hiring_reason,
        position: item.hiring_position
      }));
      setHiringData(transformedData);
    }
    if (currentStepData?.training.length > 0) {
      const transformedData = currentStepData.training.map((item) => ({
        key: item.id.toString(),
        name: item.training_name,
        reason: item.training_reason,
        position: item.training_position
      }));
      setTrainingData(transformedData);
    }
  }, [currentStepData]);

  useEffect(() => {
    window.addEventListener('stepNavigationNext', onNext);
    return () => {
      window.removeEventListener('stepNavigationNext', onNext);
    };
  }, [onNext]);

  return (
    <React.Fragment>
      <div className="flex flex-col gap-6 px-6">
        <GenericTable columns={hiringColumns} dataSource={hiringData} />
        <GenericTable columns={trainingColumns} dataSource={trainingData} />
      </div>
      <StepNavigation
        onNext={onNext}
        className="border-t-1 border-t-[#F3F3F5] mt-6 pt-6 px-6"
      />
    </React.Fragment>
  );
}
